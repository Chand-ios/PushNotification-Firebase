//
//  ViewController.swift
//  PushApp
//
//  Created by iblesoft on 02/06/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

