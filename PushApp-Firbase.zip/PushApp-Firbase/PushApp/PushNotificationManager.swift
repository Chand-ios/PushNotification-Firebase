//
//  PushNotificationManager.swift
//  Farm29
//
//  Created by FLYPIGEON on 27/05/22.
//

import UIKit
import Firebase
import UserNotifications
import FirebaseMessaging
enum Identifiers {
  static let viewAction = "VIEW_IDENTIFIER"
  static let newsCategory = "NEWS_CATEGORY"
}
class PushNotificationManager: NSObject, MessagingDelegate, UNUserNotificationCenterDelegate {
    let notificationDelegate = SampleNotificationDelegate()

    var ftoken: String = ""
//       init(token: String) {
//           self.token = token
//           super.init()
//       }
    
       func registerForPushNotifications() {
           if #available(iOS 10.0, *) {
               // For iOS 10 display notification (sent via APNS)
               UNUserNotificationCenter.current().delegate = notificationDelegate
               let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
               UNUserNotificationCenter.current().requestAuthorization(
                   options: authOptions,
                   completionHandler: {_, _ in })
               // For iOS 10 data message (sent via FCM)
               Messaging.messaging().delegate = self
           } else {
               let settings: UIUserNotificationSettings =
                   UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
               UIApplication.shared.registerUserNotificationSettings(settings)
               let viewAction = UNNotificationAction(
                 identifier: Identifiers.viewAction, title: "View",
                 options: [.foreground])
               
               let newsCategory = UNNotificationCategory(
                 identifier: Identifiers.newsCategory, actions: [viewAction],
                 intentIdentifiers: [], options: [])
               
               UNUserNotificationCenter.current()
                 .setNotificationCategories([newsCategory])
           }
           UIApplication.shared.registerForRemoteNotifications()
           updateFirestorePushTokenIfNeeded()
       }
       func updateFirestorePushTokenIfNeeded() {
           if let token = Messaging.messaging().fcmToken {
               //let usersRef = Firestore.firestore().collection("users_table").document(userID)
               //usersRef.setData(["fcmToken": token], merge: true)
               print("DeviceToken:",token)
               ftoken = token
             
               DispatchQueue.main.async { [self] in
//                   let timer = Timer.scheduledTimer(timeInterval: 864000, target: self, selector: #selector(tokenRefresh), userInfo: nil, repeats: true)
//                   pushNotionAPI(token: token)
               }
              
           }
       }
//    @objc func tokenRefresh(_ timer1: Timer) {
//        refreshToken(fcmToekn: ftoken)
//    }
//       func messaging(_ messaging: Messaging, didReceive remoteMessage: MessagingRemoteMessage) {
//           print(remoteMessage.appData)
//       }
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
           updateFirestorePushTokenIfNeeded()
       }
       func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
           print(response)
       }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
            
            // @NOTE: this fires when the app is open. So you can go the call screen right away
            let payload = notification.request.content.userInfo as! [String:Any?]
        print(payload)
            let type = payload["notificationType"]
            
            print(">> this fires if the app is currently open")

        }
    
/*    func pushNotionAPI(token:String)
    {
        let udid = UIDevice.current.identifierForVendor?.uuidString

        RecentlyItemsViewModel.getPushNotifivations(fcmtoken: token, deviceID: udid ?? "", type: "ios",  completion: {  result in
                switch result {
                case .success(let profileModel):
                   
                    print(profileModel)
                    
                case .failure(let error):
                    print(error.localizedDescription)
                    
                }
            })
        }
    func refreshToken(fcmToekn:String)
    {
        LoginView.refreshToken(token: AppStorage.refreshToken ?? "", completion: { [self] result in
            switch result {
            case .success(let profileModel):
                AppStorage.userToken = "\(profileModel.access ?? "")"
                AppStorage.refreshToken = "\(profileModel.refresh ?? "")"
               
                print("usertoken:\(profileModel.access ?? "")")
                
            case .failure(let error):
                print(error.localizedDescription)
                
            }
        })
    }*/
    
   }
